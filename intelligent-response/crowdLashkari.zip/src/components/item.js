export const Item = ({name}) => {
	return (
		<div>
			<h3>{name}</h3>
		</div>
	)
}
