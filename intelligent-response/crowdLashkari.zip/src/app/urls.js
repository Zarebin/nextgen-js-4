export const foodFactUrl = "http://localhost:8000/api/food_fact";
export const loginUrl = "http://localhost:8000/api/users/login";
export const registerUrl = "http://localhost:8000/api/users/register";
