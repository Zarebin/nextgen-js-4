export const itemNames = [
  {
    name: "Food Fact",
    img_link:
      "https://dailynorthwestern.com/wp-content/uploads/2022/05/summerlunch-Gemma-DeCetra.png",
    link: "/foodFact",
  },
  ];
